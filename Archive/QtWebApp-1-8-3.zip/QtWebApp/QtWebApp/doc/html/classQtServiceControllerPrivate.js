var classQtServiceControllerPrivate =
[
    [ "q_ptr", "classQtServiceControllerPrivate.html#ac02268c462ca6440fddb3c319639da11", null ],
    [ "serviceName", "classQtServiceControllerPrivate.html#ab0c1b3e4f6189e131073b85d869a9823", null ]
];