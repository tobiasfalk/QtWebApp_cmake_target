var classQtServiceStarter =
[
    [ "QtServiceStarter", "classQtServiceStarter.html#ac192dd9044e8ff6a663a456d88e16fdc", null ],
    [ "slotStart", "classQtServiceStarter.html#adfd8ef0a999b55ca6eeefafee52cf8dc", null ]
];