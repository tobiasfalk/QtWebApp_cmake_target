var classstefanfrings_1_1HttpConnectionHandlerPool =
[
    [ "HttpConnectionHandlerPool", "classstefanfrings_1_1HttpConnectionHandlerPool.html#a8ce1d865b1efd7495b5ce55f5d12a3ab", null ],
    [ "~HttpConnectionHandlerPool", "classstefanfrings_1_1HttpConnectionHandlerPool.html#a2473cc5157bd6546e9acd0df14c29637", null ],
    [ "getConnectionHandler", "classstefanfrings_1_1HttpConnectionHandlerPool.html#aa7d15239af996e1989960e9f09409bc2", null ]
];