var classstefanfrings_1_1TemplateCache =
[
    [ "TemplateCache", "classstefanfrings_1_1TemplateCache.html#aaac3a5eefcc6fad1e280e022ba87b6c3", null ],
    [ "tryFile", "classstefanfrings_1_1TemplateCache.html#a82621fb5262920f2dd981c5f0047db51", null ]
];