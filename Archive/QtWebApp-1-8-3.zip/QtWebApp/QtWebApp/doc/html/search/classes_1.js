var searchData=
[
  ['filelogger_154',['FileLogger',['../classstefanfrings_1_1FileLogger.html',1,'stefanfrings']]]
];
