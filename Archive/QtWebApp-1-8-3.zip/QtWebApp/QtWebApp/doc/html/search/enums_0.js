var searchData=
[
  ['requeststatus_322',['RequestStatus',['../classstefanfrings_1_1HttpRequest.html#a45b0d7b99dbbb1b2c62afd8f51887995',1,'stefanfrings::HttpRequest']]]
];
