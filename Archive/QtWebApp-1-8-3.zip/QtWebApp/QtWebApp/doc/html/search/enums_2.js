var searchData=
[
  ['serviceflag_405',['ServiceFlag',['../classQtServiceBase.html#af6e74a87329ef64760783364538e5d51',1,'QtServiceBase']]],
  ['startuptype_406',['StartupType',['../classQtServiceController.html#a946ac2b079d9760503da923c2eaf0aac',1,'QtServiceController']]]
];
