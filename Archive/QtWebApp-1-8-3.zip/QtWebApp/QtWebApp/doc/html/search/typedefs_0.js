var searchData=
[
  ['tsocketdescriptor_321',['tSocketDescriptor',['../httpconnectionhandler_8h.html#aac9d80ca2f2f3e2c74506d3b207b02d6',1,'stefanfrings']]]
];
